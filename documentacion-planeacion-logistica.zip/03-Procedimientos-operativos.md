# Procedimientos Operativos Estándar (POE)

Documentación paso a paso de los procedimientos logísticos principales.

## 📥 Recepción de Mercancía

1. Verificar orden de compra
2. Inspeccionar cantidades y estado físico
3. Registrar en el sistema
4. Etiquetar y almacenar

## 📤 Despacho

1. Recibir lista de picking
2. Verificar productos
3. Empacar y etiquetar
4. Despachar según ruta asignada

Todos los procesos deben estar acompañados de formatos de control y verificación.
