# Documentación de Procesos en Planeación Logística

Este repositorio contiene la documentación de procesos logísticos enfocados en la planeación, ejecución y mejora continua de operaciones. 

## 📌 Autor
**Abel García Manjarrés**  
Especialista en logística y operaciones.

## 📦 Objetivo del Proyecto
Brindar un conjunto organizado de documentos que describen procedimientos logísticos estandarizados, útiles para:

- Optimizar recursos en centros de distribución
- Diseñar procesos de recepción y despacho
- Controlar el inventario eficientemente
- Aplicar principios de mejora continua

## 📚 Contenido

- `01-Diagnostico-logistico.md` → Diagnóstico inicial del proceso actual
- `02-Mapa-de-procesos.md` → Estructura general del sistema logístico
- `03-Procedimientos-operativos.md` → Procedimientos detallados paso a paso
- `04-Metricas-y-KPIs.md` → Indicadores de gestión y medición del desempeño
- `05-Mejoras-propuestas.md` → Acciones para optimizar la planeación logística

## 🔧 En desarrollo
Este proyecto está en evolución. Se actualizará con nuevos documentos y análisis según la experiencia práctica en campo.

## 🤝 Licencia
Uso personal y profesional con fines educativos.
